// 2 variables globales à modifier dans l'écouteur window.onload
var countries = {
    "names": [], // ["Afghanistan", ...]
    "codes": {}, // {"Afghanistan":"AF", ...}
    "flags": {} // {"Afghanistan":"data:image...", ...}
};

var continents = []; // [{"Asia":["Afghanistan","Armenia",...]}, ...]


window.addEventListener("load", (event) => {
    // Q1 Extraction des noms de pays à partir du tableau HTML
    let CountriesNamesTmp=[];
    CountriesNamesTmp=Array.from(document.querySelectorAll("td"));
    CountriesNamesTmp.forEach(element => {
        countries.names.push(element.textContent);
    });
    console.log(countries.names);

    // Q2 Extraction des codes de pays du fichier country_codes.json
    fetch('country_codes.json', {
            method: 'GET'
        })
        .then((response) => response.json())
        .then((country_codes) => {
            console.log('Success:', country_codes);
            country_codes.forEach(function(element){
                let nomPays=Object.getOwnPropertyNames(element)[0];
                countries.codes[nomPays]=element[nomPays];
            });
            console.log(countries.codes);
            return countries.codes;
        })
        .catch((error) => {
            console.error('Error:', error);
        });

    // Q3 Extraction des continents de pays à partir du tableau country_continents (importé de country_continents.js) 
    for(i of country_continents){
        let dejaPresent=false;
        let NomContinent=i["continent"];
        for(j of continents){
            if(NomContinent==Object.getOwnPropertyNames(j)[0]){
                dejaPresent=true;
            }
        }
        if(dejaPresent==false){
            let objet={};
            objet[NomContinent]=[i["country"]];
            continents.push(objet);
        }
        else{
            let objet=continents.find((element)=> Object.getOwnPropertyNames(element)[0]==NomContinent);
            objet[NomContinent].push(i["country"]);
        }
    }

    function compare(e1,e2){
        if(Object.getOwnPropertyNames(e1)[0]>Object.getOwnPropertyNames(e2)[0]){
            return 1;
        }
        return -1;
    }

    continents.sort(compare);

    console.log(continents);

    // Q4 Extraction des drapeaux de pays à partir de la constante country_flags (importée de country_flags.js) 
    for(i of country_flags){
        let nomPays=i["country"];
        let data=i["flag_base64"];
        countries.flags[nomPays]=data;
    }
    //console.log(countries.flags);

    // Q5 Mise en forme CSS
    let td=document.querySelectorAll("td");
    td.forEach(element => {
        element.style.fontSize="75%";
        element.style.textAlign= "center";
    });
    div=document.querySelector("body > div:nth-child(2)");
    div2=document.querySelector("body > div:nth-child(2) > div:nth-child(1)");
    div.classList.add("row");
    div2.classList.add("side");
});



let handleSelectors = function() {
    // Q6 Gestion du menu
    document.getElementById('continents').addEventListener("change",(e) => {
        let td=document.querySelectorAll("td");
        let ContinentDemande=e.target.value;
        if(ContinentDemande!="all"){
            let continentPays = continents.filter(cont => Object.keys(cont)[0]===ContinentDemande);
            let continentNomPays = continentPays[0][ContinentDemande];
            td.forEach(function(t){
                if(continentNomPays.includes(t.id)){
                    t.style.visibility="visible";
                }
                else{
                    t.style.visibility = "hidden";
                }
            })
        }
        else{
            td.forEach(function(t){
                t.style.visibility="visible";
            })
        }
    })
}();

let handleRadios = function() {
    // Q7 gestion des boutons radio
    document.querySelectorAll("input[name=pays]").forEach(function(btn){
        btn.addEventListener("click",function(e){
            let checked = Array.from(document.querySelectorAll("input[name=pays]")).filter((e)=>e.checked)[0].value;
            let tds = document.querySelectorAll("td");
            if(checked ==  "noms"){
                tds.forEach(function(td){
                    td.innerHTML=td.id;
                })
            }
            if(checked ==  "codes"){
                tds.forEach(function(td){
                    td.innerHTML=countries.codes[td.id];
                })
            }
            if(checked ==  "drapeaux"){
                tds.forEach(function(td){
                    td.innerHTML="";
                    let img = document.createElement("img");
                    img.src=countries.flags[td.id];
                    img.alt=td.id;
                    img.className="flag";
                    td.appendChild(img);
                })
            }
        })
    })
}();

let handleHeader = function f() {
    let tds = document.querySelectorAll("td");
    tds.forEach(function(td) {
        td.addEventListener("click", function(e) {
            let country_name = e.target.id;
            if (country_name) {
                fetch('country_features.php', {
                        method: 'POST',
                        body: new URLSearchParams("country_name=" + country_name),
                    })
                    .then((response) => response.json())
                    .then((country) => {
                        console.log('Success:', country);
                        // Q8 clic sur cellule
                        // A COMPLETER <---
                        // --> A COMPLETER
                        return country;
                    })
                    .catch((error) => {
                        console.error('Error:', error);
                    });
            }
        });
    });
}();