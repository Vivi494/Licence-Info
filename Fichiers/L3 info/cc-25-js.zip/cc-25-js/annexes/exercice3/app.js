import { 
  attachThemeToggle,
   getPersistedTheme ,
  getThemeFromURL,
   showImageAlert ,
  preloadImage ,
  setGlowColorUtils,
  withTimeout,
  applyThemeClasses
} from './utils.js';

import {
p_loadSchema,
p_buildForm,
p_flash,
p_attachSFX,
p_setGlowColor,
p_attachEyesGlow,
p_attachBatsOnOctober,
p_spawnBats,
p_halloweenDomLayer,
p_postToServer,
p_fetchArtById,
p_startRitualSequence,
p_hookRitualOnSubmit,
p_main
} from './p_app.js'


/*=============================================================================
=                                   QUESTION 1                                =
=                       Charger le schéma et gérer le statut                  =
=============================================================================*/
/**
 * loadSchema(theme)
 * Charge et retourne le schéma du formulaire selon le thème choisi et met à jour le statut.
 *
 * Pré-conditions :
 *  - theme ∈ {'light', 'dark'}.
 *
 * Post-conditions :
 *  - #status affiche succès ou erreur puis est masqué après un court délai.
 *  - Promesse résolue avec le schéma sélectionné ou rejetée en cas d’échec.
 */
function loadSchema(theme) {
  let status = document.getElementById("status")
  status.classList.toggle("visually-hidden")
  let page_title = document.getElementById("page-title")
  return fetch("data/forms.json")
  .then(response => response.json())
  .then(obj => {
    return obj[theme]
  })
  .then(obj => {
    console.log(obj)
    if(theme=="dark"){
      page_title.textContent=obj["title"]+" - Halloween"
    }
    else{
      page_title.textContent=obj["title"]
    }
    return obj
  })
  .then( obj => {
    status.textContent="Chargement Réussi"
    return obj
  })
  .then(obj => {
    setTimeout(()=>(status.classList.toggle("visually-hidden")),4000)
    return obj
  })
  .catch(status.textContent="Echec du Chargement")

   //return p_loadSchema(theme);
}


/*=============================================================================
=                          QUESTION 2 – Lueur dynamique                       =
=============================================================================*/
/**
 * setGlowColor(hex)
 * Applique un halo au conteneur du formulaire selon le code couleur hex en paramètre
 * 
 * Pré-conditions :
 *  - hex : string dénotant un code couleur en hexadécimal
 * 
 */
function setGlowColor(hex) {
   // conversion du code hexadécimal en code RGBA
  const rgba = setGlowColorUtils(hex);
  document.documentElement.style.setProperty('--hallo-glow', rgba);
   // halo à appliquer
  const box_shadow_ = `0 0 24px 8px ${rgba}, 0 0 2px 1px ${rgba}`;

  // A remplacer
  p_setGlowColor(hex);
}

/** 
 * attachEyesGlow()
 * Fixe l'ombrage du formulaire sur la base du champ de couleur des yeux dès qu'il est saisi ou modifié.
 */
function attachEyesGlow() {
  // A remplacer
  p_attachEyesGlow();
}

/*=============================================================================
=                         QUESTION 3 – Chauves-souris                         =
=============================================================================*/
/**
 * spawnBats(n = 6)
 * Génére n chauves-souris éphémères.
 */
function spawnBats(n=6){
  // A remplacer
  p_spawnBats(n);
}

/**
 * attachBatsOnOctober()
 * Génère 8 chauves-souris éphémères quand "octobre" est choisi.
 */
function attachBatsOnOctober() {
  // A remplacer
  p_attachBatsOnOctober();
}

/*=============================================================================
=                  QUESTION 4 – Récupération des visuels (art)                 =
=============================================================================*/
/**
 * fetchArtById(choiceId)
 * Charge data/monster-art.json, en extrait le nom du fichier image correspondant à choiceId 
 * et précharge l'image. Utilise l'id xkqzpae7821bcd93ef41 si l'id demandé n'existe pas.
 */
function fetchArtById(choiceId) {
  // A compléter en utilisant les 2 instructions suivantes pour résoudre la promesse
  // (succès pour la 1ere et échec pour la 2nde)
  //return withTimeout(preloadImage(chosen.src), 1800).then(img => ({ img, meta: chosen }));
  //return { img: null, meta: { error: true, message: err.message } };

  // A commenter
  return p_fetchArtById(choiceId);

}


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% A NE PAS CHANGER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

/*=============================================================================
=                       Flash visuel                                          =
=============================================================================*/
/**
 * flash(node)
 * Déclenche une courte lueur/impulsion visuelle sur un élément (ex: container).
 */
function flash(node){
  p_flash(node);
}

/*=============================================================================
=       Générer dynamiquement <form> à partir du schéma                       =
=============================================================================*/
/**
 * buildForm(schema)
 * Construit un formulaire accessible et minimaliste à partir d’un schéma.
 */
function buildForm(schema) {
  p_buildForm(schema);
}

/*=============================================================================
=              hookRitualOnSubmit      =
=============================================================================*/
(function hookRitualOnSubmit() {
  p_hookRitualOnSubmit();
})();


/*============================================================================
=                       startRitualSequence                                   =
=============================================================================*/
/**
 * startRitualSequence(fd, actionURL)
 * Orchestre animations (chauves-souris + lueur), envoi serveur, et image.
 *
 * Retour :
 *  - Promise qui résout en un objet { artRes, serverRes } :
 *      - artRes : { img: HTMLImageElement | null, meta: Object }
 *      - serverRes : réponse JSON renvoyée par le serveur (ou un objet d'erreur)
 */
function startRitualSequence(fd, actionURL) {
  return p_startRitualSequence(fd,actionURL);
}

/*=============================================================================
=                                   postToServer                              =
=============================================================================*/
/**
 * postToServer(fd, actionURL)
 * Envoie le formulaire au serveur via POST et renvoie la réponse JSON.
 */
function postToServer(fd, actionURL) {
  return p_postToServer(fd,actionURL);
}

/*=============================================================================
=                                   MAIN                                      =
=============================================================================*/
(function main(){
  // Ordre de priorité: ?theme= > localStorage > 'light'
  const urlTheme = getThemeFromURL();
  const stored = getPersistedTheme();
  const theme = urlTheme || stored || 'light';
  applyThemeClasses(theme);     // applique .halloween si dark
  attachThemeToggle(theme);     // branche le bouton #themeSwitch
  loadSchema(theme)
    .then(schema => {buildForm(schema);
      p_halloweenDomLayer();
      if (theme == 'dark') {
        attachEyesGlow();      // lueur suivant la couleur des yeux
        p_attachSFX();     // flash sur changement d'arme
        attachBatsOnOctober(); //envol de chauves-souris en octobre
    }
  })
    .catch(() => {
      const container = document.getElementById('form-container');
      container.innerHTML = '<p role="alert">Impossible de charger le formulaire.</p>';
    });

})();
