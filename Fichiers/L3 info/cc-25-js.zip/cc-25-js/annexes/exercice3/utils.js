







/* ===== Helpers inchangés ===== */
export const delay = (ms) => new Promise(res => setTimeout(res, ms));
export function withTimeout(promise, ms) {
  return Promise.race([ promise, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms)) ]);
}



export function preloadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload  = () => resolve(img);
    img.onerror = () => reject(new Error('image load error: ' + src));
    img.src = src;
  });
}

/* ===== Alert custom qui affiche une image + JSON ===== */
export function showImageAlert({ title = 'Aperçu', imgSrc, meta }) {
  // style rapide injecté 1x
  if (!document.getElementById('img-alert-style')) {
    const st = document.createElement('style');
    st.id = 'img-alert-style';
    st.textContent = `
      .imgAlert-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:9999}
      .imgAlert-modal{width:min(90vw,520px);background:#0f172a;color:#e5e7eb;border:1px solid #1f2937;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.4);overflow:hidden}
      .imgAlert-head{display:flex;justify-content:space-between;align-items:center;padding:.6rem .9rem;background:#111827;border-bottom:1px solid #1f2937}
      .imgAlert-head h3{margin:0;font:600 1rem/1.2 system-ui}
      .imgAlert-close{border:0;background:transparent;color:#e5e7eb;font-size:1.1rem;cursor:pointer}
      .imgAlert-body{padding:.75rem}
      .imgAlert-body img{width:100%;height:auto;border-radius:8px;margin-bottom:.6rem;display:block}
      .imgAlert-body pre{margin:0;background:#0b1220;padding:.6rem;border-radius:8px;white-space:pre-wrap;word-break:break-word;max-height:36vh;overflow:auto;border:1px solid #1f2937}
      .imgAlert-actions{display:flex;justify-content:flex-end;gap:.5rem;padding:.6rem .9rem;border-top:1px solid #1f2937;background:#0f172a}
      .imgAlert-actions button{padding:.45rem .7rem;border-radius:8px;border:1px solid #374151;background:#111827;color:#e5e7eb;cursor:pointer}
    `;
    document.head.appendChild(st);
  }

  const wrap = document.createElement('div');
  wrap.className = 'imgAlert-backdrop';
  wrap.innerHTML = `
    <div class="imgAlert-modal" role="dialog" aria-modal="true" aria-label="${title}">
      <div class="imgAlert-head">
        <h3>${title}</h3>
        <button class="imgAlert-close" aria-label="Fermer">×</button>
      </div>
      <div class="imgAlert-body">
        <img alt="aperçu">
        <pre></pre>
      </div>
      <div class="imgAlert-actions">
        <button class="imgAlert-close">Fermer</button>
      </div>
    </div>`;
  document.body.appendChild(wrap);

  const img = wrap.querySelector('img');
  const pre = wrap.querySelector('pre');
  img.src = imgSrc || '';
  img.style.display = imgSrc ? 'block' : 'none';
  pre.textContent = JSON.stringify(meta || {}, null, 2);

  const closeAll = () => wrap.remove();
  wrap.addEventListener('click', (e) => { if (e.target === wrap) closeAll(); });
  wrap.querySelectorAll('.imgAlert-close').forEach(b => b.addEventListener('click', closeAll));

  // focus UX
  setTimeout(() => wrap.querySelector('.imgAlert-close')?.focus(), 0);
}

export function getThemeFromURL() {
  const params = new URLSearchParams(window.location.search);
  return params.get('theme'); // 'dark' | 'light' | null
}
export function getPersistedTheme() {
  return localStorage.getItem('theme'); // 'dark' | 'light' | null
}
export function persistTheme(theme) {
  localStorage.setItem('theme', theme);
}



export function setGlowColorUtils(hex) {
  if (!/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(hex)) return;
  const h = hex.replace('#','');
  const [r,g,b] = (h.length === 3)
    ? h.split('').map(c => parseInt(c+c,16))
    : [h.slice(0,2),h.slice(2,4),h.slice(4,6)].map(x=>parseInt(x,16));
  const rgba = `rgba(${r}, ${g}, ${b}, .35)`;
  return rgba;
}


// ------- Toggle de thème (doit recharger la page) -------
export function attachThemeToggle(currentTheme) {
  const btn = document.getElementById('themeSwitch');
  btn.addEventListener('click', () => {
    const next = currentTheme === 'dark' ? 'light' : 'dark';
    persistTheme(next);

    // Choix: forcer le paramètre ?theme= pour respecter l’énoncé
    const url = new URL(window.location.href);
    url.searchParams.set('theme', next);
    // Rechargement contrôlé
    window.location.href = url.toString();
  });
}

export function applyThemeClasses(theme) {
  const isDark = theme === 'dark';
  document.body.classList.toggle('dark', isDark);
  document.body.classList.toggle('halloween', isDark);
  const switchBtn = document.getElementById('themeSwitch');
  const labelSpan = switchBtn.querySelector('.toggle-label');
  labelSpan.textContent = isDark ? 'Dark' : 'Light';
  document.getElementById('page-title').textContent =
    isDark ? 'Formulaire dynamique – Halloween' : 'Formulaire dynamique';
}

