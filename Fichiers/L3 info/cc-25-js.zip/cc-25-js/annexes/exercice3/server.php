<?php
// server.php
header('Content-Type: application/json; charset=utf-8');

function read_json($path) {
  $raw = @file_get_contents($path);
  if ($raw === false) {
    http_response_code(500);
    echo json_encode(['ok'=>false, 'message'=>'Impossible de lire '.$path], JSON_UNESCAPED_UNICODE);
    exit;
  }
  $data = json_decode($raw, true);
  if (!is_array($data)) {
    http_response_code(500);
    echo json_encode(['ok'=>false, 'message'=>'JSON invalide: '.$path], JSON_UNESCAPED_UNICODE);
    exit;
  }
  return $data;
}

$monstre = isset($_POST['monstre']) ? trim($_POST['monstre']) : '';
$prenom  = isset($_POST['prenom']) ? trim($_POST['prenom']) : '';

// 1) Table de correspondance (unique source du lien type -> id)
$mapTypeToId = [
  'vampire'     => 'xkqzpae7821bcd93ef41',
  'loup-garou'  => 'hjkwy77uz6789cad45fb02',
  'sorciere'    => 'plmnvtr2134bfa98de56',
  'citrouille'  => 'bvxqtpl3344eda79cf15',
  'spectre'     => 'hjkwyuz6789cad45fb02',
  'zombie'      => 'qsdnwer9856eda74cf23',
  'halloween'   => 'zrtyuio9928fab73de41'   // fallback générique
];



// 2) Id déterminé sans random (prend celui de la table, sinon fallback)
$typeKey = mb_strtolower($monstre);
$desiredId = $mapTypeToId[$typeKey] ?? 'hw-00';

// 3) Validation contre le JSON: l'id doit exister, sinon fallback “hw-00”, sinon 1er item
$db    = read_json(__DIR__.'/data/monster-art.json');
$items = isset($db['items']) && is_array($db['items']) ? $db['items'] : [];
$ids   = array_column($items, 'id');
if (!in_array($desiredId, $ids, true)) {
  $desiredId = in_array('hw-00', $ids, true) ? 'hw-00' : ($ids[0] ?? null);
}

if ($desiredId === null) {
  echo json_encode(['ok'=>false, 'message'=>'Aucune image disponible'], JSON_UNESCAPED_UNICODE);
  exit;
}

// 4) Réponse minimale: on renvoie uniquement l’id (le front résoudra src/comment)
echo json_encode([
  'ok' => true,
  'choice' => [
    'id' => $desiredId
  ],
  'echo' => [
    'prenom'  => $prenom,
    'monstre' => $monstre
  ]
], JSON_UNESCAPED_UNICODE);
?>