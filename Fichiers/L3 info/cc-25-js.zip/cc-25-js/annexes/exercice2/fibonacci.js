// A IMPLEMENTER : fonction F asynchrone pour calculer le nombre de Fibonacci

async function F(n){
    if(n=0){
        return 0
    }
    else if(n=1){
        return 1
    }
    else if(n>1){
        return F(n-1)+F(n-2)
    }
}

export default F;
