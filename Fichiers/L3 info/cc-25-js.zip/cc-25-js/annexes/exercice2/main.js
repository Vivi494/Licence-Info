import F from './fibonacci.js';

// Valeurs à utiliser
const n1 = 5;
const n2 = 20;
const n3 = 25;

// 1. Affichage séquentiel
async function displaySequential() {
    await F(n1)
    await F(n2)
    await F(n3)
}

// 2. Affichage inversé
async function displayReversed() {
    await F(n3)
    await F(n2)
    await F(n1)
}

// 3. Affichage simultané
async function displaySimultaneous() {
    F(n1)
    F(n2)
    F(n3)
}

// Test des fonctions
displaySequential();
displayReversed();
displaySimultaneous();
