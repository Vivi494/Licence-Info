import Person from './person.js';

// créer la classe Student

class Student extends Person{
    #grades;
    constructor(nom,age,grades){
        super(nom,age)
        this.#grades=grades
    }
    getAverage(){
        let total=0;
        let nb=0;
        this.#grades.forEach(element => {
            total=total+element
            nb=nb+1
        });
        return total/nb
    }
    get grades(){
        return this.#grades
    }
}

export default Student;