import Student from './student.js';

// données d'étudiants en JSON
const studentsJSON = '[{"name": "Goscinny","age": 99,"grades": [  14,  16,  12,  18]}, {"name": "Uderzo","age": 98,"grades": [  8,  16,  16,  8]}]';

document.addEventListener('DOMContentLoaded', () => {
  const resultDiv = document.getElementById('result');

  // Crée l'instance de Student correspondant au 1er étudiant fourni dans `studentsJSON`
  const etudiant1 = JSON.parse(studentsJSON)[0];
  const student = new Student(etudiant1.name, etudiant1.age, etudiant1.grades);

  // Affiche les détails de l'étudiant, de ses notes et de sa moyenne
  resultDiv.innerHTML = `
    <p>Nom et âge : ${student.getDetails()}</p>
    <p>Notes : ${student.grades.join(", ")}</p>
    <p>Moyenne : ${student.getAverage()}</p>
  `;
});
