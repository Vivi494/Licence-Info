// créer la classe Person

class Person{
    nom;
    age;
    constructor(nom,age){
        this.nom=nom
        this.age=age
    }
    getDetails(){
        return this.nom+" "+this.age
    }
}

export default Person;