let puzzle = null;

fetch('puzzle.json', {
        method: 'GET'
    })
    .then((response) => response.json())
    .then((puzzles) => {
        // Extraction du premier puzzle et construction du générateur
        console.log('Success:', puzzles);
        puzzle = puzzles[0];
        let generator = new PuzzleGenerator(puzzle);

        // Q1.1 Injection de l'auteur
        // generator.insertAuthor();
        let a = document.createElement("a")
        a.href=puzzles[0]["url"]
        a.innerHTML=puzzles[0]["auteur"]
        let p1 = document.querySelector("p");
        p1.appendChild(a)

        // Q1.2 Injection des images
        // generator.insertImages();

        puzzles[0]["images"].forEach(element => {
            let request = new Request("img/"+element["src"])
            let alt = element["alt"]
            let div1 = document.querySelector("#images")
            fetch(request)
            .then((reponse) => {
                if(reponse.ok){
                    return reponse.blob()
                }
            else{
                console.log("Erreur ",reponse.status)
            }})
            .then(image => {
                let url = URL.createObjectURL(image)
                let img = document.createElement("img")
                img.src = url
                img.alt = alt
                img.width = 30
                img.height = 50
                div1.appendChild(img)
            });
        });

        // Q1.3 Injection de l'énoncé
        // generator.insertStatement();
        let enonce = document.createElement("p")
        let div2 = document.querySelector("body > div:nth-child(3)")
        enonce.innerHTML=puzzles[0]["énoncé"]
        div2.appendChild(enonce)

        // Injection des en-têtes du tableau (ne pas faire cette question)
        generator.insertTableHeaders();

        // Q1.4 Injection des indices
        // generator.insertHints();
        let olIndice = document.querySelector("body > form:nth-child(5) > div:nth-child(1) > ol:nth-child(2)")
        puzzles[0]["indices"].forEach(element => {
            console.log(element)
        })

        // Q1.5 Injection des menus déroulants
        // generator.insertDropDowns();

        // Q2.1 Clic sur cellules
        // generator.handleClicks();

        // Q2.2 Cochage des indices
        // generator.handleHints();

        // Q3 Gestion du formulaire
        // generator.handleDropDowns();

        return puzzle;
    })
    .catch((error) => {
        console.error('Error:', error);
    });



// Q4 Minuteur