let puzzle = null;

fetch('puzzle.json', {
        method: 'GET'
    })
    .then((response) => response.json())
    .then((puzzles) => {
        // Extraction du premier puzzle et construction du générateur
        console.log('Success:', puzzles);
        puzzle = puzzles[0];
        let generator = new PuzzleGenerator(puzzle);

        // Q1.1 Injection de l'auteur
        // generator.insertAuthor();
        let a = document.createElement("a")
        a.href=puzzles[0]["url"]
        a.innerHTML=puzzles[0]["auteur"]
        let p1 = document.querySelector("p");
        p1.appendChild(a)

        // Q1.2 Injection des images
        // generator.insertImages();

        puzzles[0]["images"].forEach(element => {
            let request = new Request("img/"+element["src"])
            let alt = element["alt"]
            let div1 = document.querySelector("#images")
            fetch(request)
            .then((reponse) => {
                if(reponse.ok){
                    return reponse.blob()
                }
            else{
                console.log("Erreur ",reponse.status)
            }})
            .then(image => {
                let url = URL.createObjectURL(image)
                let img = document.createElement("img")
                img.src = url
                img.alt = alt
                img.width = 30
                img.height = 50
                div1.appendChild(img)
            });
        });

        // Q1.3 Injection de l'énoncé
        // generator.insertStatement();
        let enonce = document.createElement("p")
        let div2 = document.querySelector("body > div:nth-child(3)")
        enonce.innerHTML=puzzles[0]["énoncé"]
        div2.appendChild(enonce)

        // Injection des en-têtes du tableau (ne pas faire cette question)
        generator.insertTableHeaders();

        // Q1.4 Injection des indices
        // generator.insertHints();
        let olIndice = document.querySelector("body > form:nth-child(5) > div:nth-child(1) > ol:nth-child(2)");
        puzzles[0]["indices"].forEach(element => {
            let checkbox = document.createElement("input");
            let label = document.createElement("label");
            let li = document.createElement("li");
            checkbox.type="checkbox";
            label.textContent=element;
            li.appendChild(checkbox);
            li.appendChild(label);
            olIndice.appendChild(li);
        })

        // Q1.5 Injection des menus déroulants
        // generator.insertDropDowns();
        let trs = document.querySelectorAll("fieldset > table > tbody >tr");
        let nb = 0;
        let ths = trs[0].querySelectorAll("th");
        let tds1 = trs[1].querySelectorAll("td");
        let tds2 = trs[2].querySelectorAll("td");
        let tds3 = trs[3].querySelectorAll("td");
        puzzles[0]["facettes"].forEach(element => {
            console.log(element["nom"])
            if(nb!=0){
                let opt1 = document.createElement("option");
                let opt2 = document.createElement("option");
                let opt3 = document.createElement("option");
                opt1.text=element["valeurs"][0];
                opt2.text=element["valeurs"][1];
                opt3.text=element["valeurs"][2];
                let select = document.createElement("select");
                select.add(opt1);
                select.add(opt2);
                select.add(opt3);
                let select2 = select.cloneNode(true);
                let select3 = select.cloneNode(true);
                ths[nb].textContent=element["nom"];
                tds1[nb].appendChild(select);
                tds2[nb].appendChild(select2);
                tds3[nb].appendChild(select3);
                
            }
            else{
                ths[nb].textContent=element["nom"];
                tds1[nb].textContent=element["valeurs"][0];
                tds2[nb].textContent=element["valeurs"][1];
                tds3[nb].textContent=element["valeurs"][2];
            }
            nb++;
        }) 

        // Q2.1 Clic sur cellules
        // generator.handleClicks();
        let aide = document.querySelector("#aide");
        let cellules = aide.querySelectorAll("table > tbody > tr > td ");
        let cellules1 = Array.from(cellules).filter((element) => {
            if(element.textContent=="" && !element.classList.contains("invisible")){
                return true;
            }
            else{
                return false;
            }
        })
        console.log(cellules1);
        cellules1.forEach(element => {
            let nbclicks = 0;
            element.addEventListener("click",((element) => {
                nbclicks++;
                if(nbclicks%3==0){
                    element.target.style.backgroundColor = "white";
                    element.target.textContent="";
                }
                else{
                    if(nbclicks%3==1){
                        element.target.style.backgroundColor = "red";
                        element.target.textContent="X";
                    }
                    else{
                        element.target.style.backgroundColor = "green";
                        element.target.textContent="O";
                    }
                }
            }))
        })

        // Q2.2 Cochage des indices
        // generator.handleHints();
        let lis = olIndice.querySelectorAll("li");
        lis.forEach(element => {
            element.querySelector("input").addEventListener("click",element => {
                if(element.target.checked==true){
                    element.target.nextSibling.style.textDecoration = "line-through" ;
                }
                else{
                    element.target.nextSibling.style.textDecoration = "initial" ;
                }
            })
        })

        // Q3 Gestion du formulaire
        // generator.handleDropDowns();

        return puzzle;
    })
    .catch((error) => {
        console.error('Error:', error);
    });



// Q4 Minuteur