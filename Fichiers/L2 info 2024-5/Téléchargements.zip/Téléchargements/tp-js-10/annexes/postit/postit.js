// A COMPLETER
function jours(date){
    const tab= ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
    return tab[date.getDay()];
}
let date=new Date;
document.querySelector("#postit").textContent=jours(date)+"\n"+date.getHours()+":"+date.getMinutes()+":"+date.getSeconds();
setInterval(()=>{
    let date=new Date;
    document.querySelector("#postit").textContent=jours(date)+"\n"+date.getHours()+":"+date.getMinutes()+":"+date.getSeconds();
},"500");