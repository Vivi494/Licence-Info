/*
 * Quand l'un des deux boutons radio est coché, remplace les 2 matrices
 * existantes par 2 matrices m x n identiques d'entiers tirés aléatoirement 
 * selon les dimensions et le type de matrices prescrits par les champs 
 * numériques et le bouton coché en appelant la fonction générerEtat().
 */
let radiob=document.getElementById("binary");
radiob.addEventListener("change",function(){
    générerEtat();
})

let radioi=document.getElementById("integer");
radioi.addEventListener("change",function(){
    générerEtat();
})
// A COMPLETER

/*
 * Remplace les 2 matrices existantes par 2 matrices m x n identiques et
 * tirées aléatoirement à chaque changement de valeur des champs 'Lignes'
 * (m) ou 'Colonnes' (n) en appelant la fonction générerEtat().
 */

// A COMPLETER
let rows=document.getElementById("rows");
rows.addEventListener("change",function(){
    générerEtat();
})

let col=document.getElementById("columns");
col.addEventListener("change",function(){
    générerEtat();
})

/*
 * Transpose la matrice modélisée par le tableau HTML 'table' passé en argument
 * si elle est carré en "transposant" le tableau (y compris ses libellés), affiche 
 * une alerte sinon.
 */
function transposer(table) {
    // A COMPLETER
    let a;
    for(let i=1;i<table.rows.length;i++){
        for(let j=i;j<table.rows[0].childElementCount;j++){
            a=table.rows[i].cells[j].textContent;
            table.rows[i].cells[j].textContent=table.rows[j].cells[i].textContent;
            table.rows[j].cells[i].textContent=a;
        }
    }
}

/*
 * Transpose la matrice de l'élément de classe 'mat2' à chaque clic sur le
 * bouton 'Transposer' uniquement si la matrice est carré, émet une alerte
 * sinon. La transposition se fait en appelant la fonction transposer(table).
 */

// A COMPLETER
let trans = document.querySelector(".transposer");
trans.addEventListener("click",function(){
    let mat2 = document.querySelector(".mat2 table");
    
    transposer(mat2);
})

/*
 * Permute les lignes i et j (où i<j) du tableau HTML 'table'.
 */
function permuterLignes(table, i, j) {
    // A COMPLETER
    let b;
    for(let a=1;a<table.rows[0].childElementCount;a++){
        b=table.rows[i].cells[a].textContent;
        table.rows[i].cells[a].textContent=table.rows[j].cells[a].textContent;
        table.rows[j].cells[a].textContent=b;
    }
}

/*
 * Permute deux lignes tirées aléatoirement (y compris leurs libellés) dans la 
 * matrice de l'élément de classe 'mat2' à chaque clic sur le bouton 'Permuter'.
 * Les tirages aléatoires s'effectuent par appel à la fonction tirerEntier().
 * La permutation de lignes s'effectue par appel à la fonction permuterLignes().
 */
// A COMPLETER
let perm = document.querySelector(".permuter");
perm.addEventListener("click",function(){
    let mat2 = document.querySelector(".mat2 table");
    permuterLignes(mat2,tirerEntier(1,4),tirerEntier(1,4));
})