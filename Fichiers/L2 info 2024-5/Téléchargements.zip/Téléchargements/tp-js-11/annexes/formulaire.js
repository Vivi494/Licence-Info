///////// UTILITAIRES ///////////////////////////////////////////////////////////////////

// Masque les "tooltips"
function deactivateTooltips() {
	// A COMPLETER
	let tool=document.querySelectorAll(".tooltip");
	tool.forEach(element => {
		element.style.display="none";
	});
}

// Renvoie le "tooltip" associé à l'élément elt (ie. l'élément qui suit elt dans sa fratrie) 
// Renvoie false si le "tooltip" n'existe pas
function getTooltip(elt) {
	// A COMPLETER
	if(elt.nextSibling!=null){
		return elt.nextSibling;
	}
	else {
 		return false;
	} 
}

// Fonction booléenne de validation et affichage :
// Si la condition "cond" est vraie : classe "correct" l'élément "elt", masque le "tooltip", et renvoie vrai
// Sinon : classe "incorrect" l'élément "elt", affiche le "tooltip", et renvoie faux
function validate(cond,elt,tooltip) {
	// A COMPLETER
	if(cond==true){
		elt.class="correct";
		tooltip.display="none";
		return true;
	}
	else{
		elt.class="incorrect";
		tooltip.display="inline-block";
		return false;
	}
}


///////// ECOUTEURS ///////////////////////////////////////////////////////////////////
// Fonctions booléennes de vérification des champs du formulaire : 1 fonction par champ.
// Chaque fonction est une méthode de l'objet "check" et dénommée selon son champ, 
// e.g. check.gender est la fonction de vérification pour le champ de nom "gender"
var check = {};
let gender=document.querySelectorAll('input[name="person[gender]"]');
check['gender'] =
validate(gender[0]!=null || gender[1]!=null,gender,getTooltip(gender[1]));// A COMPLETER
let last=document.querySelector('input[name="person[lastName]"]');
check['lastName'] = 
validate(last.length>1,last,getTooltip(last));// A COMPLETER
let first=document.querySelector('input[name="person[firstName]"]');
check['firstName'] = validate(first.length>1,first,getTooltip(first));// A COMPLETER
let age=document.querySelector('input[name="person[age]"]');
check['age'] = validate(age>5 && age<140,age,getTooltip(age));// A COMPLETER
let login=document.querySelector('input[name="person[login]"]');
check['login'] = validate(login.length>3,login,getTooltip(login));// A COMPLETER
let pwd1=document.querySelector('input[name="person[password]"]');
check['pwd1'] = validate(pwd1.length>6,pwd1,getTooltip(pwd1));// A COMPLETER
let pwd2=document.querySelector('input[name="person[pwd2]"]');
check['pwd2'] = validate(pwd2=pwd1,pwd2,getTooltip(pwd2));// A COMPLETER
let country=document.querySelector('select[name="person[country]"]');
check['country'] = 	validate(country!=null,country,getTooltip(country));// A COMPLETER


	///////// GESTIONNAIRES D'EVENEMENTS /////////////////////////////////////////////////////
(function() { // IIFE pour éviter les variables globales.
	var myForm = document.querySelector('#myForm');
	var select = document.querySelector('select');

	// A COMPLETER : ENREGISTREMENT DES GESTIONNAIRES POUR LES DIFFERENTS CHAMPS
	// UTILISANT LES DIFFERENTES FONCTIONS DE VERIFICATION. 
	myForm.addEventListener("submit",function(){
		check['gender'];
		check['lastName'];
		check['firstName'];
		check['age'];
		check['login'];
		check['pwd1'];
		check['pwd2'];
		check['country'];
	})
	myForm.addEventListener("reset",function(){
		check['gender'];
		check['lastName'];
		check['firstName'];
		check['age'];
		check['login'];
		check['pwd1'];
		check['pwd2'];
		check['country'];
	})
	gender.forEach(e=>e.addEventListener("click",function(){
		check['gender']
	}));
	last.addEventListener("keyup",function(){
		check['lastName']
	});
	first.addEventListener("keyup",function(){
		check['firstName']
	});
	age.addEventListener("keyup",function(){
		check['age']
	});
	login.addEventListener("keyup",function(){
		check['login']
	});
	pwd1.addEventListener("keyup",function(){
		check['pwd1']
	});
	pwd2.addEventListener("keyup",function(){
		check['pwd2']
	});
	select.addEventListener("mouseup",function(){
		check['country']
	});
})();

///////// DESACTIVATION PAR DEFAUT ///////////////////////////////////////////////////////////////
deactivateTooltips();
