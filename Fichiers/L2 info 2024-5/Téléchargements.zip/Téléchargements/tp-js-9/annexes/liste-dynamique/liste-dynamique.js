// A COMPLETER
let ajout=document.getElementById("ajouter");
let ul=document.createElement("ul");
document.getElementById("ici").appendChild(ul);
ajout.addEventListener("click",function(){
    let li=document.createElement("li");
    ul.appendChild(li);
    li.textContent=prompt("Ajout : ");
})
let suppr=document.getElementById("supprimer");
suppr.addEventListener("click",function(){
    ul.remove();
    ul=document.createElement("ul");
    document.getElementById("ici").appendChild(ul);
})