// Variable fonctionnelle JS dénotant et implémentant la fonction choisie par le visiteur 
let f = function(x) {
    return x;
};

// Ecouteur du menu déroulant
let selectlistener = document.querySelector("#fx");
selectlistener.addEventListener("change", function(e) {
    // A COMPLETER
    switch (selectlistener.value){
        case "linear":
            f=function(x){
                return x;
            }
            break;
        case "quadratic":
            f=function(x){
                return x*x;
            }
            break;
        default:
            selectlistener.value="linear";
            break;
    }
});


// Renvoie le tableau a = [x1 + ((i * (x2 - x1)) / n) | i = 0..n] 
// qui segmente [x1,x2] en n intervalles contigus et de mêmes tailles
function segmentation(x1, x2, n) {
    // A COMPLETER
    let a = Array(n+1);
    for(let i=0;i<n+1;i++){
        a[i] = x1 + ((i * (x2 - x1)) / n);
    }
    return a;
}

// Renvoie l'approximation de la valeur de l'intégrale de f sur [x1,x2]
// obtenue par la méthode des rectangles à GAUCHE basée sur une décomposition en n intervalles
function integrale_rectangle_gauche(f, x1, x2, n) {
    let a = segmentation(x1, x2, n);
    r = 0.0;
    for (let i = 0; i < n; ++i) {
        r += Math.abs(f(a[i]));
    }

    return (r * (x2 - x1)) / n;
}

// Renvoie l'approximation de la valeur de l'intégrale de f sur [x1,x2]
// obtenue par la méthode des rectangles à DROITE basée sur une décomposition en n intervalles
function integrale_rectangle_droite(f, x1, x2, n) {
    let a = segmentation(x1, x2, n);
    r = 0.0;
    for (let i = 0; i < n; ++i) {
        r += Math.abs(f(a[i+1]));
    }

    return (r * (x2 - x1)) / n;
}

// Renvoie l'approximation de la valeur de l'intégrale de f sur [x1,x2] par la méthode des trapèzes
function integrale_trapeze(f, x1, x2, n) {
    return (integrale_rectangle_gauche(f, x1, x2, n) + integrale_rectangle_droite(f, x1, x2, n)) / 2;
}

// Renvoie l'approximation de la valeur de l'intégrale de f sur [x1,x2] par la méthode de Simpson
function integrale_simpson(f, x1, x2, n) {
    let a = segmentation(x1, x2, n);
    let r = 0.0;
    for (let i = 0; i < n; ++i) {
        r += (a[i + 1] - a[i]) / 6 * (f(a[i]) + 4 * f((a[i] + a[i + 1]) / 2) + f(a[i + 1]));
        console.log(r);
    }

    return r;
}

// Ecouteur du bouton "calculer"
// A COMPLETER
let calc= document.querySelector("input[value='calculer']");
calc.addEventListener("click",function(){
    let itv=parseInt(document.getElementById("itv").value);
    let x1=parseInt(document.getElementById("x1").value);
    let x2=parseInt(document.getElementById("x2").value);
    document.getElementById("y1").value=f(x1);
    document.getElementById("y2").value=f(x2);
    document.getElementById("meth1").value=integrale_rectangle_droite(f,x1,x2,itv);
    document.getElementById("meth2").value=integrale_trapeze(f,x1,x2,itv);
    document.getElementById("meth3").value=integrale_simpson(f,x1,x2,itv);
})

// Ecouteur du bouton "effacer"
// A COMPLETER
let res= document.querySelector("input[value='effacer']");
res.addEventListener("click",function(){
    document.getElementById("y1").value="";
    document.getElementById("y2").value="";
    document.getElementById("meth1").value="";
    document.getElementById("meth2").value="";
    document.getElementById("meth3").value="";
})