// A COMPLETER
let bouton=document.getElementById("bt");
let x=0;
let y=0;
bouton.addEventListener("click",function(){
    if(bouton.value==="Créer une question"){
        bouton.value="Montrer la réponse";
        bouton.style.backgroundColor="green";
        x=Math.floor(Math.random()*11);
        y=Math.floor(Math.random()*11);
        let q= document.getElementById("question");
        q.textContent="Combien font "+x+" fois "+y+" ? ";
    }
    else if(bouton.value==="Montrer la réponse"){
        bouton.value="Créer une question";
        bouton.style.backgroundColor="LightCoral";
        let r= document.getElementById("reponse");
        r.textContent=x*y;
    }
})